package com.majd.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class VersionsAdapter extends RecyclerView.Adapter<VersionsAdapter.VH> {

    public interface OnItemClickListener {
        void onItemClick(View view, int position, AndroidVersion item);
    }

    private final List<AndroidVersion> data;
    private final OnItemClickListener listener;

    public VersionsAdapter(List<AndroidVersion> data, OnItemClickListener listener) {
        this.data = data;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_android_version, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        AndroidVersion item = data.get(position);
        holder.codeName.setText(item.getCodeName());
        holder.version.setText(item.getVersion());
        holder.logo.setImageResource(item.getImageResId());

        int color = holder.itemView.getResources().getColor((position % 2 == 0) ? R.color.row_even : R.color.row_odd);
        ((CardView) holder.itemView).setCardBackgroundColor(color);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(v, holder.getAdapterPosition(), item);
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView logo;
        TextView codeName, version;
        VH(@NonNull View itemView) {
            super(itemView);
            logo = itemView.findViewById(R.id.logo);
            codeName = itemView.findViewById(R.id.codeName);
            version = itemView.findViewById(R.id.version);
        }
    }
}