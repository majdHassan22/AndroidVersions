package com.majd.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity implements VersionsAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private VersionsAdapter adapter;
    private final List<AndroidVersion> data = new ArrayList<>();
    private Button btnSortName, btnSortVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new VersionsAdapter(data, this);
        recyclerView.setAdapter(adapter);

        btnSortName = findViewById(R.id.btnSortName);
        btnSortVersion = findViewById(R.id.btnSortVersion);

        btnSortName.setOnClickListener(v -> sortByName());
        btnSortVersion.setOnClickListener(v -> sortByVersionDesc());

        seedData();
        sortByName(); // افتراضي
    }

    private void seedData() {
        data.clear();
        data.add(new AndroidVersion(R.drawable.logo_donut, "Donut", "1.6"));
        data.add(new AndroidVersion(R.drawable.logo_eclair, "Éclair", "2.0 – 2.1"));
        data.add(new AndroidVersion(R.drawable.logo_froyo, "Froyo", "2.2 – 2.2.3"));
        data.add(new AndroidVersion(R.drawable.logo_gingerbread, "Gingerbread", "2.3 – 2.3.7"));
        data.add(new AndroidVersion(R.drawable.logo_honeycomb, "Honeycomb", "3.0 – 3.2.6"));
        data.add(new AndroidVersion(R.drawable.logo_ics, "Ice Cream Sandwich", "4.0 – 4.0.4"));
        data.add(new AndroidVersion(R.drawable.logo_jellybean, "Jelly Bean", "4.1 – 4.3.1"));
        data.add(new AndroidVersion(R.drawable.logo_kitkat, "KitKat", "4.4 – 4.4.4"));
        data.add(new AndroidVersion(R.drawable.logo_lollipop, "Lollipop", "5.0 – 5.1.1"));
        data.add(new AndroidVersion(R.drawable.logo_marshmallow, "Marshmallow", "6.0 – 6.0.1"));
        data.add(new AndroidVersion(R.drawable.logo_nougat, "Nougat", "7.0 – 7.1.2"));
        data.add(new AndroidVersion(R.drawable.logo_oreo, "Oreo", "8.0 – 8.1"));
    }

    private void sortByName() {
        Collections.sort(data, (a, b) -> a.getCodeName().compareToIgnoreCase(b.getCodeName()));
        adapter.notifyDataSetChanged();
    }

    private void sortByVersionDesc() {
        Collections.sort(data, new Comparator<AndroidVersion>() {
            private float startVersion(@NonNull String v) {
                String s = v.replace("–", "-");
                String first = s.split("-")[0].trim();
                try {
                    return Float.parseFloat(first);
                } catch (NumberFormatException e) {
                    return 0f;
                }
            }
            @Override
            public int compare(AndroidVersion o1, AndroidVersion o2) {
                return Float.compare(startVersion(o2.getVersion()), startVersion(o1.getVersion()));
            }
        });
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClick(View view, int position, AndroidVersion item) {
        String msg = getString(R.string.you_selected, item.getCodeName(), item.getVersion());
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}