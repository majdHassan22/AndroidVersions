package com.majd.myapplication;

public class AndroidVersion {
    private int imageResId;
    private String codeName;
    private String version;

    public AndroidVersion(int imageResId, String codeName, String version) {
        this.imageResId = imageResId;
        this.codeName = codeName;
        this.version = version;
    }

    public int getImageResId() {
        return imageResId;
    }

    public void setImageResId(int imageResId) {
        this.imageResId = imageResId;
    }

    public String getCodeName() {
        return codeName;
    }

    public void setCodeName(String codeName) {
        this.codeName = codeName;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}